import React from 'react';
declare const NotificationList: ({ NotificationArray, handleNotificationClick, OnClearall }: any) => React.JSX.Element;
export default NotificationList;
//# sourceMappingURL=NotificationList.d.ts.map
import * as React from 'react';
import "../../horizontalNavBar/components/horizontalNavbar.scss";
import "../../../CustomCss/mainCustom.scss";
declare const HorizontalNavbar: () => React.JSX.Element;
export default HorizontalNavbar;
//# sourceMappingURL=HorizontalNavBar2.d.ts.map
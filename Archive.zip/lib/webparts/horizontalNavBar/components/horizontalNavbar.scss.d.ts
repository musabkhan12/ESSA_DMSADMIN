declare const styles: {};
export default styles;
//# sourceMappingURL=horizontalNavbar.scss.d.ts.map
export interface IHorizontalNavBarProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    context: any;
    siteUrl: string;
}
export declare const ListTitleTiSearchCategoryMapping: any;
//# sourceMappingURL=IHorizontalNavBarProps.d.ts.map
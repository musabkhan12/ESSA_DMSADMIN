declare const styles: {};
export default styles;
//# sourceMappingURL=horizontalNavbar2.scss.d.ts.map
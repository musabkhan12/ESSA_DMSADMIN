import * as React from 'react';
import "../../horizontalNavBar/components/horizontalNavbar.scss";
import "../../../CustomCss/mainCustom.scss";
declare const HorizontalNavbar: ({ _context, siteUrl }: any) => React.JSX.Element;
export default HorizontalNavbar;
//# sourceMappingURL=HorizontalNavBar.d.ts.map
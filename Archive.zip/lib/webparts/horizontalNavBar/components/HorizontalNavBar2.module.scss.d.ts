declare const styles: {
    horizontalNavBar: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=HorizontalNavBar2.module.scss.d.ts.map
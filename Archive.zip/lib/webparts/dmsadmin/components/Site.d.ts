import * as React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import { WebPartContext } from '@microsoft/sp-webpart-base';
import "@pnp/sp/site-groups";
import "@pnp/sp/folders";
import "@pnp/sp/webs";
import "./CreateFoldercss";
interface Sitemainprops {
    context: WebPartContext;
}
declare const Site: React.FC<Sitemainprops>;
export default Site;
//# sourceMappingURL=Site.d.ts.map
declare global {
    interface Window {
        view: (message: string) => void;
        deleteFile: (fileId: string, siteID: string, listToUpdate: any) => void;
    }
}
import * as React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "@pnp/sp/webs";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/sites";
import "@pnp/sp/presets/all";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "./dmscss";
import "./DMSAdmincss";
import { IDmsMusaibProps } from './IDmsMusaibProps';
import './MyApprovalscss';
declare const DMSMyApproval: React.FC<IDmsMusaibProps>;
export default DMSMyApproval;
//# sourceMappingURL=MyApprovals.d.ts.map
import React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
interface ManageFolderPermissionProps {
    OthProps: {
        [key: string]: string;
    };
    onReturnToMain: () => void;
}
declare const ManageFolderPermission: React.FC<ManageFolderPermissionProps>;
export default ManageFolderPermission;
//# sourceMappingURL=ManageFolderPermission.d.ts.map
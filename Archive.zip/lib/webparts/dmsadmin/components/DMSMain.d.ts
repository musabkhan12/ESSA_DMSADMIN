declare global {
    interface Window {
        managePermission: (DocumentLibraryName: string, SiteTilte: string, SiteID: string) => void;
        manageWorkflow: (DocumentLibraryName: string, SiteTilte: string, SiteID: string) => void;
        view: (message: string) => void;
        PreviewFile: (path: string, siteID: string, docLibName: any, filemasterlist: any, filepreview: any) => void;
        deleteFile: (fileId: string, siteID: string, listToUpdate: any) => void;
        shareFile: (fileID: String, siteId: String, currentFolderPathForFile: string, fileName: string) => void;
        editFile: (siteName: string, documentLibraryName: string) => void;
    }
}
import * as React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "@pnp/sp/webs";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/sites";
import "@pnp/sp/presets/all";
import "@pnp/sp/webs";
import "@pnp/sp/sites";
import "@pnp/sp/site-users/web";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "../../verticalSideBar/components/VerticalSidebar.scss";
import "./dmscss.css";
import { IDmsMusaibProps } from './IDmsMusaibProps';
declare const DMSMain: React.FC<IDmsMusaibProps>;
export default DMSMain;
//# sourceMappingURL=DMSMain.d.ts.map
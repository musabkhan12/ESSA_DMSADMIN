import * as React from 'react';
import { SPFI } from '@pnp/sp';
import { BasicFormProps } from '../components/BasicFormProps';
interface CreateDivisionProps extends BasicFormProps {
    sp: SPFI;
    onSubmit?: () => void;
}
declare const CreateDevision: React.FC<CreateDivisionProps>;
export default CreateDevision;
//# sourceMappingURL=CreateDivison.d.ts.map
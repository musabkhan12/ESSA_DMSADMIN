import * as React from 'react';
import { SPFI } from '@pnp/sp';
import { BasicFormProps } from '../components/BasicFormProps';
interface CreateDepartmentProps extends BasicFormProps {
    sp: SPFI;
    onSubmit?: () => void;
}
declare const CreateDepartment2: React.FC<CreateDepartmentProps>;
export default CreateDepartment2;
//# sourceMappingURL=CreateDepartment.d.ts.map
import * as React from 'react';
declare function CreateEntity(): React.JSX.Element;
export default CreateEntity;
//# sourceMappingURL=CreateEntity%20B.d.ts.map
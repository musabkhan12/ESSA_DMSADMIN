import * as React from 'react';
import { SPFI } from '@pnp/sp';
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
interface DepartmentProps {
    sp: SPFI;
}
declare const Department: React.FC<DepartmentProps>;
export default Department;
//# sourceMappingURL=Department.d.ts.map
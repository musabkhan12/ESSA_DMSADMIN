import * as React from 'react';
import { SPFI } from '@pnp/sp';
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "../../verticalSideBar/components/VerticalSidebar.scss";
import "../../../CustomCss/mainCustom.scss";
import "../../verticalSideBar/components/VerticalSidebar.scss";
import { WebPartContext } from '@microsoft/sp-webpart-base';
interface ManageSuperProps {
    sp: SPFI;
    context: WebPartContext;
}
export declare const ManageSuper: React.FC<ManageSuperProps>;
export {};
//# sourceMappingURL=ManageSuper.d.ts.map
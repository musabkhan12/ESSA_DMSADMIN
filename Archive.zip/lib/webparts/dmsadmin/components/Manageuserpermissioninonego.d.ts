import * as React from "react";
import { SPFI } from "@pnp/sp";
import './Manageuserpermissioninonego.css';
import "@pnp/sp/webs";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/sites";
import "@pnp/sp/presets/all";
import "@pnp/sp/site-groups";
interface IUserPermissionManagerProps {
    sp: SPFI;
    siteCollections: {
        value: string;
        label: string;
        siteUrl: string;
        id: any;
    }[];
    context: any;
}
export default function UserPermissionManager(props: IUserPermissionManagerProps): React.JSX.Element;
export {};
//# sourceMappingURL=Manageuserpermissioninonego.d.ts.map
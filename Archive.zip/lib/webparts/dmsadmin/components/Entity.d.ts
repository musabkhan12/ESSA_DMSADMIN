import * as React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import { WebPartContext } from "@microsoft/sp-webpart-base";
interface ICreateEntityProps {
    context: WebPartContext;
    siteUrl?: string | null;
    siteCollections?: any[];
}
declare const Entity: React.FC<ICreateEntityProps>;
export default Entity;
//# sourceMappingURL=Entity.d.ts.map
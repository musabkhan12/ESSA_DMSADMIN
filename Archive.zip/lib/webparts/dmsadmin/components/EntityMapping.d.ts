import * as React from 'react';
import { SPFI } from '@pnp/sp';
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "../../verticalSideBar/components/VerticalSidebar.scss";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "../../verticalSideBar/components/VerticalSidebar.scss";
interface EntityMappingProps {
    sp: SPFI;
}
declare const EntityMapping: React.FC<EntityMappingProps>;
export default EntityMapping;
//# sourceMappingURL=EntityMapping.d.ts.map
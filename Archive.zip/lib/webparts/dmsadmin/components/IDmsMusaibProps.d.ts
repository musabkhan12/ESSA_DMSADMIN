export interface IDmsMusaibProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    context: any;
    siteUrl: string;
}
//# sourceMappingURL=IDmsMusaibProps.d.ts.map
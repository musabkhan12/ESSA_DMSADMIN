import * as React from 'react';
import "@pnp/sp/webs";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/sites";
import "@pnp/sp/presets/all";
import "@pnp/sp/site-groups";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { SPFI } from "@pnp/sp";
import { WebPartContext } from "@microsoft/sp-webpart-base";
interface BasicFormProps {
    sp: SPFI;
    context: WebPartContext;
    currentId: any;
    currentJobTitle: any;
    currentIsActive: any;
    onCancel: any;
    IsExternal: any;
    selectedSiteFilter?: string;
    siteCollections?: any[];
    setSelectedSiteFilter?: React.Dispatch<React.SetStateAction<string>>;
}
declare const BasicForm: React.FC<BasicFormProps>;
export default BasicForm;
//# sourceMappingURL=CreateMasterDemo.d.ts.map
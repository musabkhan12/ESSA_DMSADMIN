import * as React from 'react';
import { SPFI } from '@pnp/sp';
export interface forMapping {
    sp: SPFI;
    currentId: number | null;
    currentEntity: string;
    currentDevision: string;
    currentDepartment: string;
    onCancel: () => void;
}
declare const CreateEntityMapping: React.FC<forMapping>;
export default CreateEntityMapping;
//# sourceMappingURL=CreateEntityMapping.d.ts.map
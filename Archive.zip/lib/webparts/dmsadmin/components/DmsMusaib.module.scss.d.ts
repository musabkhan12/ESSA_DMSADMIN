declare const styles: {
    dmsMusaib: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=DmsMusaib.module.scss.d.ts.map
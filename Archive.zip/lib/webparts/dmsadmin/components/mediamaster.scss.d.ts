declare const styles: {};
export default styles;
//# sourceMappingURL=mediamaster.scss.d.ts.map
export interface IDmsadminProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    context: any;
    siteUrl: string;
}
//# sourceMappingURL=IDmsadminProps.d.ts.map
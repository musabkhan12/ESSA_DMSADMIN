declare global {
    interface Window {
    }
}
import * as React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "../../verticalSideBar/components/VerticalSidebar.scss";
import "@pnp/sp/webs";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/sites";
import "@pnp/sp/presets/all";
import "@pnp/sp/site-groups";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "../../verticalSideBar/components/VerticalSidebar.scss";
import "./dmscss";
import "./DMSAdmincss";
import { IDmsMusaibProps } from './IDmsMusaibProps';
declare const DMSAdmin: React.FC<IDmsMusaibProps>;
export default DMSAdmin;
//# sourceMappingURL=DMSadmin.d.ts.map
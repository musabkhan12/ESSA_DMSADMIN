import React from "react";
import { SPFI } from "@pnp/sp";
interface ManageFolderDeligationProps {
    sp: SPFI;
    onBack: () => void;
    siteCollections: {
        value: string;
        label: string;
        siteUrl: string;
        id: any;
    }[];
    context: any;
}
declare const ManageFolderDeligation: React.FC<ManageFolderDeligationProps>;
export default ManageFolderDeligation;
//# sourceMappingURL=ManageFolderDeligation.d.ts.map
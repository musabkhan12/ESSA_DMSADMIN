declare const styles: {};
export default styles;
//# sourceMappingURL=CustomTable.scss.d.ts.map
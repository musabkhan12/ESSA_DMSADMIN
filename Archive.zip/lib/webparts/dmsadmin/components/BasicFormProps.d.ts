export interface BasicFormProps {
    currentId: any;
    currentJobTitle: any;
    currentIsActive: any;
    onCancel: any;
}
//# sourceMappingURL=BasicFormProps.d.ts.map
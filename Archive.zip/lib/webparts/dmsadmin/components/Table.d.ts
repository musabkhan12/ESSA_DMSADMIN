import * as React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "@pnp/sp/webs";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/sites";
import "@pnp/sp/presets/all";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "./dmscss";
import "./MediaMaster.module.scss";
import "./mediamaster.scss";
import "./CustomTable.scss";
interface CreateFolderProps {
    Currentbuttonclick: {
        [key: string]: string;
    };
    onReturnToMain: () => void;
}
declare const Table: React.FC<CreateFolderProps>;
export default Table;
//# sourceMappingURL=Table.d.ts.map
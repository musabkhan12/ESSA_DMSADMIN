import * as React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
declare const Entity: () => React.JSX.Element;
export default Entity;
//# sourceMappingURL=EntityDemo.d.ts.map
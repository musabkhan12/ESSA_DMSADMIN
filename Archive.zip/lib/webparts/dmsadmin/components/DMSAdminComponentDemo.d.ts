declare global {
    interface Window {
    }
}
import * as React from "react";
import "@pnp/graph/groups";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "../../verticalSideBar/components/VerticalSidebar.scss";
import "@pnp/sp/webs";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/sites";
import "@pnp/sp/presets/all";
import "@pnp/sp/site-groups";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "../../verticalSideBar/components/VerticalSidebar.scss";
import "./dmscss";
import "./DMSAdmincss";
import { WebPartContext } from "@microsoft/sp-webpart-base";
interface IDmsMusaibProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    siteUrl: string;
    context: WebPartContext;
    someOtherProp?: any;
}
declare const DMSAdmin: React.FC<IDmsMusaibProps>;
export default DMSAdmin;
//# sourceMappingURL=DMSAdminComponentDemo.d.ts.map
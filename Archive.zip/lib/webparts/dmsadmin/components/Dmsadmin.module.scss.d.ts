declare const styles: {
    dmsadmin: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Dmsadmin.module.scss.d.ts.map
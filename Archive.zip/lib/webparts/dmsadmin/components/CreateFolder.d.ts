import * as React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "@pnp/sp/folders";
import "@pnp/sp/webs";
import "./CreateFoldercss";
interface CreateFolderProps {
    OthProps: {
        [key: string]: string;
    };
    onReturnToMain: () => void;
}
declare const CreateFolder: React.FC<CreateFolderProps>;
export default CreateFolder;
//# sourceMappingURL=CreateFolder.d.ts.map
import * as React from "react";
import "@pnp/sp/webs";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import './uploadfilecss';
interface UploadFileProps {
    currentfolderpath: {
        [key: string]: string;
    };
    onReturnToMain: () => void;
}
declare const UploadFile: React.FC<UploadFileProps>;
export default UploadFile;
//# sourceMappingURL=UploadFile.d.ts.map
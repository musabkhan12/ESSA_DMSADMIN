declare const styles: {
    mediaMaster: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=MediaMaster.module.scss.d.ts.map
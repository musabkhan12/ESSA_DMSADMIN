import React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
interface CreateFolderProps {
    OthProps: {
        [key: string]: string;
    };
    onReturnToMain: () => void;
}
declare const ManageWorkFlow: React.FC<CreateFolderProps>;
export default ManageWorkFlow;
//# sourceMappingURL=ManageWorkFlow.d.ts.map
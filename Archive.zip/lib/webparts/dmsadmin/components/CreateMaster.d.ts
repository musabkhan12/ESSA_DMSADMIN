import * as React from 'react';
interface BasicFormProps {
    currentId: any;
    currentJobTitle: any;
    currentIsActive: any;
    onCancel: any;
    IsExternal: any;
}
declare const BasicForm: React.FC<BasicFormProps>;
export default BasicForm;
//# sourceMappingURL=CreateMaster.d.ts.map
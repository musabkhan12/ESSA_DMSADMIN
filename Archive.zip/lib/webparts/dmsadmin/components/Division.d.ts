import * as React from 'react';
import { SPFI } from '@pnp/sp';
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
interface DevisionProps {
    sp: SPFI;
}
declare const Devision: React.FC<DevisionProps>;
export default Devision;
//# sourceMappingURL=Division.d.ts.map
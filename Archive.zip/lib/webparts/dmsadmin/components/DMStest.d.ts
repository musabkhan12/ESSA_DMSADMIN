declare global {
    interface Window {
        managePermission: (DocumentLibraryName: string, SiteTilte: string, SiteID: string) => void;
        manageWorkflow: (DocumentLibraryName: string, SiteTilte: string, SiteID: string) => void;
        view: (message: string) => void;
        deleteFile: (fileId: string, siteID: string, listToUpdate: any) => void;
    }
}
import * as React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "@pnp/sp/webs";
import "@pnp/sp/folders";
import "@pnp/sp/files";
import "@pnp/sp/sites";
import "@pnp/sp/presets/all";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../../CustomCss/mainCustom.scss";
import "./dmscss";
import { IDmsMusaibProps } from './IDmsMusaibProps';
declare const ArgPocMain2: React.FC<IDmsMusaibProps>;
export default ArgPocMain2;
//# sourceMappingURL=DMStest.d.ts.map
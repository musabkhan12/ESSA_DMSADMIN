import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/batching";
import "@pnp/sp/site-users/web";
import "@pnp/sp/profiles";
import "@pnp/sp/items/get-all";
import "@pnp/sp/folders";
import "@pnp/sp/files/folder";
import "@pnp/sp/fields";
import { MSGraphClientV3 } from "@microsoft/sp-http";
export declare const getSP: (context?: WebPartContext) => SPFI;
/**
* Initializes and returns an MSGraphClient instance for Graph API calls.
* @param context - SPFx WebPartContext to initialize the MSGraphClient.
*/
export declare const getGraphClient: (context: WebPartContext) => Promise<MSGraphClientV3>;
//# sourceMappingURL=pnpjsConfig.d.ts.map
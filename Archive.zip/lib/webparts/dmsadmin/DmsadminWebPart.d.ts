import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IDmsadminWebPartProps {
    description: string;
}
export default class DmsadminWebPart extends BaseClientSideWebPart<IDmsadminWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    render(): void;
    protected onInit(): Promise<void>;
}
//# sourceMappingURL=DmsadminWebPart.d.ts.map
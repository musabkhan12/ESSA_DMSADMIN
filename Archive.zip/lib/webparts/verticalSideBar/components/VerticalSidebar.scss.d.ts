declare const styles: {};
export default styles;
//# sourceMappingURL=VerticalSidebar.scss.d.ts.map
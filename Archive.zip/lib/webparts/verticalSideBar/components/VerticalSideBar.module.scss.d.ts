declare const styles: {
    verticalSideBar: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=VerticalSideBar.module.scss.d.ts.map
import * as React from 'react';
import "../components/VerticalSidebar.scss";
import "../../horizontalNavBar/components/horizontalNavbar.scss";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/webs";
import "../../../Assets/Figtree/Figtree-VariableFont_wght.ttf";
import "@pnp/graph/users";
import "@pnp/graph/photos";
declare const VerticalSideBar: ({ _context, component }: any) => React.JSX.Element;
export default VerticalSideBar;
//# sourceMappingURL=VerticalSideBar.d.ts.map
/// <reference types="react" />
declare const UserContext: import("react").Context<{}>;
export default UserContext;
//# sourceMappingURL=context.d.ts.map
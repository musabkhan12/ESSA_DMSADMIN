import * as React from 'react';
interface ProviderProps {
    children: React.ReactNode;
}
declare const Provider: React.FC<ProviderProps>;
export default Provider;
//# sourceMappingURL=provider.d.ts.map
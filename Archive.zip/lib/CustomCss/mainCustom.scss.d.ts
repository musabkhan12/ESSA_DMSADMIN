declare const styles: {};
export default styles;
//# sourceMappingURL=mainCustom.scss.d.ts.map
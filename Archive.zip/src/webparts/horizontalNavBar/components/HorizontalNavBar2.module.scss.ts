/* tslint:disable */
require("./HorizontalNavBar2.module.css");
const styles = {
  horizontalNavBar: 'horizontalNavBar_7383df82',
  teams: 'teams_7383df82',
  welcome: 'welcome_7383df82',
  welcomeImage: 'welcomeImage_7383df82',
  links: 'links_7383df82'
};

export default styles;
/* tslint:enable */
/* tslint:disable */
require("./horizontalNavbar2.css");
const styles = {

};

export default styles;
/* tslint:enable */
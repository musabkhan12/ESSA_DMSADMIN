/* tslint:disable */
require("./MediaMaster.module.css");
const styles = {
  mediaMaster: 'mediaMaster_e556ecb4',
  teams: 'teams_e556ecb4',
  welcome: 'welcome_e556ecb4',
  welcomeImage: 'welcomeImage_e556ecb4',
  links: 'links_e556ecb4'
};

export default styles;
/* tslint:enable */
/* tslint:disable */
require("./Dmsadmin.module.css");
const styles = {
  dmsadmin: 'dmsadmin_8136cdc3',
  teams: 'teams_8136cdc3',
  welcome: 'welcome_8136cdc3',
  welcomeImage: 'welcomeImage_8136cdc3',
  links: 'links_8136cdc3'
};

export default styles;
/* tslint:enable */
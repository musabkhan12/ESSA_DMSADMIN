/* tslint:disable */
require("./DmsMusaib.module.css");
const styles = {
  dmsMusaib: 'dmsMusaib_ced3ce92',
  teams: 'teams_ced3ce92',
  welcome: 'welcome_ced3ce92',
  welcomeImage: 'welcomeImage_ced3ce92',
  links: 'links_ced3ce92'
};

export default styles;
/* tslint:enable */
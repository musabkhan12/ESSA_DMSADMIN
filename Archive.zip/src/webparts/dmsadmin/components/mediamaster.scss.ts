/* tslint:disable */
require("./mediamaster.css");
const styles = {

};

export default styles;
/* tslint:enable */